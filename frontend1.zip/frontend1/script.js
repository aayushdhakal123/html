
document.addEventListener('DOMContentLoaded', function() {
    var navbarToggle = document.getElementById('navbar-toggle');
    var navbarMenu = document.querySelector('.navbar-menu');
  
    navbarToggle.addEventListener('change', function() {
        if (this.checked) {
        navbarMenu.style.display = 'block';
      } else {
        navbarMenu.style.display = 'none';
      }
    });
  });
